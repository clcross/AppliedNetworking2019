<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Problem 2</title>
    <link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body>
    <div align="center">
    <h1>Buy Your Movie Tickets From Cameron!</h1>
    <hr/>

    <form action="<?=$_SERVER['PHP_SELF']?>" method="post"> 
        Enter Number of Adults:<input type="text" name="Adult" placeholder="Price: $6"/>
        Enter Number of Children:<input type="text" name="Child" placeholder="Price: $4"/><br/><br/>
        <input type="submit" name="submit" value="Purchase Tickets"/>
    </form>

    <br/>

    <?php
        if(isset($_POST["submit"]))
        {
            if(!is_numeric($_POST["Adult"]))
            {
                $error1="<p>You did not enter a numeric value for 'Adult'</p><br/>";
            }
            if(!is_numeric($_POST["Child"]))
            {
                $error2="<p>You did not enter a numeric value for 'Child'</p><br/>";
            }
            if(!empty($error1))
            {
                echo $error1;
            }
            if(!empty($error2))
            {
                echo $error2;
            }
            if(empty($error1) && empty($error2))
            {
                $adult=($_POST["Adult"] * 6);
                $child=($_POST["Child"] * 4);
                $total=($adult + $child);

                echo "<p>Total Cost: $" . $total . "</p><br/>";
            }
        }
    ?>
    </div>
</body>
</html>